-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 08:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `160420070_anmp_uts`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `author` varchar(200) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `newsText` text NOT NULL,
  `newsPicDir` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `author`, `summary`, `newsText`, `newsPicDir`) VALUES
(1, 'Orange cat racism', 'Not an Orange', 'Orange cats face persecution..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://cdn.britannica.com/70/234870-050-D4D024BB/Orange-colored-cat-yawns-displaying-teeth.jpg'),
(3, 'Black cats: Good or Bad luck?', 'Black Cat Association', 'Black cats are often seen as unlucky. However..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://upload.wikimedia.org/wikipedia/commons/4/4c/Blackcat-Lilith.jpg'),
(8, 'Life for old strays', 'Straffordshire Shelter', 'Old cats are very rarely seen in the wild, due to the many..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://ichef.bbci.co.uk/news/976/cpsprodpb/24BE/production/_123760490_mediaitem123760488.jpg'),
(9, 'The Male Calico', 'Calicats, Inc.', 'While nearly all calico cats are female, some male calico cats may exist. This is due to..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://www.catster.com/wp-content/uploads/2018/03/Calico-cat.jpg'),
(10, 'Why do white cats often have two different eye colors?', 'Harvard University', 'White cats are commonly seen with two differing eye colors. Research has shown that..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://www.rover.com/blog/wp-content/uploads/white-cat-min.jpg'),
(11, 'When is it right to separate kittens?', 'The Cat Breeding Association', 'It is often hard to gauge the difference between the kitten and adolescent phase in cat development. However..', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce interdum pellentesque ligula, at lobortis turpis condimentum vitae. Maecenas in orci porttitor, mollis purus vel, sagittis lacus. Proin magna neque, molestie ac nisl at, pulvinar vestibulum diam. Nullam luctus, metus eget vehicula accumsan, diam nunc convallis odio, et scelerisque elit est ac augue. Suspendisse potenti. Sed vitae augue fermentum diam porta mattis. Pellentesque eget sagittis ante. Suspendisse cursus risus at orci dictum rhoncus. Duis maximus dolor vitae ex suscipit efficitur. Etiam vitae erat ac arcu tempus laoreet eget vel leo. Integer viverra ultricies dapibus. Etiam interdum magna eget cursus dignissim.\r\n\r\nProin eu fringilla massa, id congue sem. Vestibulum id arcu fringilla, semper est nec, molestie enim. Mauris at justo eget lectus viverra ornare consequat id nibh. Quisque mattis hendrerit luctus. Quisque consectetur, velit ac semper placerat, dolor libero dapibus sem, eget semper risus libero sed dui. Curabitur fermentum justo augue, non tristique nibh rhoncus at. Sed eget sem lobortis, condimentum magna dignissim, placerat neque. Donec volutpat ultricies varius. Duis auctor risus vitae urna euismod, a laoreet justo gravida. Duis eu nulla turpis. Sed non gravida tellus.\r\n\r\nDonec id dignissim lorem. Maecenas viverra posuere tellus in ornare. Duis ut mi dolor. Aenean consequat imperdiet massa, quis egestas libero. Ut sit amet vulputate libero. Phasellus sed porttitor mi. Proin vestibulum dapibus justo ac commodo. Aenean commodo dignissim ligula, sed finibus nisi hendrerit sit amet.\r\n\r\nNulla laoreet molestie ligula sed ornare. Praesent id velit eleifend, pharetra dui at, fermentum massa. Donec laoreet laoreet massa nec finibus. Mauris eu risus a metus tempus ultrices at eget mauris. Maecenas a facilisis odio. Maecenas vitae nisi quis nisi dapibus gravida. Praesent turpis ligula, tincidunt a gravida vitae, aliquet quis lectus. Integer diam mi, molestie ac tincidunt a, pulvinar non ex. Nulla euismod tellus a arcu sodales, nec fringilla est imperdiet.\r\n\r\nNam feugiat porttitor pellentesque. Proin nec venenatis turpis. Sed ut nisl ornare, suscipit nisi sit amet, efficitur eros. Suspendisse finibus tellus consequat lectus malesuada, ac laoreet lorem placerat. Vestibulum eget feugiat diam, in blandit ex. Pellentesque fermentum sem eu ipsum porta fringilla. In euismod erat efficitur consequat molestie. Proin a scelerisque nulla, sed porttitor massa. Aenean in nisi leo. Cras vitae consectetur lacus. Donec tempor tristique magna, posuere vestibulum lorem elementum in. Sed viverra maximus dolor, ac faucibus nibh condimentum et. Donec aliquet leo eros, nec suscipit mauris mattis molestie. ', 'https://upload.wikimedia.org/wikipedia/commons/b/bc/Juvenile_Ragdoll.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `firstName` varchar(200) NOT NULL,
  `lastName` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `firstName`, `lastName`, `username`, `email`, `password`) VALUES
(1, 'Jimmy', 'Camry', 'jcam', 'jcameron@gmail.com', 'Catboi'),
(10, 'Canis', 'the Dog', 'felinecat', 'feline@cat.com', 'canine123'),
(11, 'Jake', 'Jabez', 'jsn', 'jsn@jbz.com', 'jsnPass22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
