<?php
	$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "160420070_anmp_uts";

    $con = new mysqli($servername, $username, $password, $dbname);

    if($_GET["action"] == "login"){
    	$sql = "SELECT * FROM user WHERE username = ". "'". $_GET["username"]. "'". " AND password = ". "'".  $_GET["password"]. "'";
	    $result = $con->query($sql);

    	$send_to_client = array();
		while($row = $result->fetch_assoc()) {
		  	$send_to_client[] = $row;
		}
		echo json_encode($send_to_client);
	   
    }
    else if($_GET["action"] == "register"){
    	$sql = $con->prepare("INSERT INTO user(firstName, lastName, username, email, password) VALUES (?, ?, ?,?,?)");
		$sql->bind_param("sssss", $firstName, $lastName, $username, $email, $password);

		$firstName = $_GET["firstName"];
		$lastName = $_GET["lastName"];
		$username = $_GET["username"];
		$email = $_GET["email"];
		$password = $_GET["password"];
		$sql->execute();

		if($con->insert_id > 0){
			$sql = "SELECT * FROM user WHERE id = ". $con->insert_id;
		    $result = $con->query($sql);

		    if ($result->num_rows > 0) {
		    	$send_to_client = array();
				while($row = $result->fetch_assoc()) {
				  	$send_to_client[] = $row;
				}
				echo json_encode($send_to_client);
		    }
		}
    }
    else if($_GET["action"] == "searchByID"){
    	$sql = "SELECT * FROM user WHERE id = ". $_GET["userID"];
	    $result = $con->query($sql);

	    if ($result->num_rows > 0) {
	    	$send_to_client = array();
			while($row = $result->fetch_assoc()) {
			  	$send_to_client[] = $row;
			}
			echo json_encode($send_to_client);
	    }
    }
    else if($_GET["action"] == "update"){
    	$sql_update = $con->prepare("UPDATE user SET firstName = ?, lastName = ?, password = ? WHERE id = ?");
		$sql_update->bind_param("sssi", $firstName, $lastName, $password, $id);

		$firstName = $_GET["firstName"];
		$lastName = $_GET["lastName"];
		$password = $_GET["password"];
		$id = $_GET["userID"];
		$sql_update->execute();

		$sql = "SELECT * FROM user WHERE id = ". $id;
	    $result = $con->query($sql);

	    if ($result->num_rows > 0) {
	    	$send_to_client = array();
			while($row = $result->fetch_assoc()) {
			  	$send_to_client[] = $row;
			}
			echo json_encode($send_to_client);
	    }
		
    }

    $con->close();
?>
