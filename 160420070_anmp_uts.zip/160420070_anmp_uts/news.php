<?php
	$servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "160420070_anmp_uts";

    $con = new mysqli($servername, $username, $password, $dbname);

    if(!isset($_GET["searchID"])){
    	$sql = "SELECT * FROM news";
    	$result = $con->query($sql);
	    if ($result->num_rows > 0) {
	    	$send_to_client = array();
			while($row = $result->fetch_assoc()) {
			  	$send_to_client[] = $row;
			}
			echo json_encode($send_to_client);
	    }
	}else{
		$sql = "SELECT * FROM news WHERE id = ". $_GET["searchID"];
		$result = $con->query($sql);
	    if ($result->num_rows > 0) {
	    	$send_to_client = array();
			while($row = $result->fetch_assoc()) {
			  	$send_to_client[] = $row;
			}
			echo json_encode($send_to_client);
	    }
	}

    $con->close();
?>
